(function($) {
  'use strict';
  $("fileuploader").dropzone({
    url: "bootstrapdash.com/"
  });
})(jQuery);